import ULA

a = ULA()
a.plot_beampattern( 77e9 )

print('Bye bye')
